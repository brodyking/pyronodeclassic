<?php
$moderators = false;
$admins = false;
$adminPW = 'secureandrandompassword5';
?>
