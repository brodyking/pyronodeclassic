<?php
session_start();
header('content-type: text/plain;');
header('refresh: 1200;');
echo 'hi there!';
?>